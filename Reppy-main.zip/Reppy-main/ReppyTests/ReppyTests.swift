//
//  ReppyTests.swift
//  ReppyTests
//
//  Created by Tyler Dang on 5/2/25.
//

import Testing
@testable import Reppy

struct ReppyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
