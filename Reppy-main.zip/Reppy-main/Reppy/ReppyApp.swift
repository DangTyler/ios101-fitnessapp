//
//  ReppyApp.swift
//  Reppy
//
//  Created by Tyler Dang on 5/2/25.
//

import SwiftUI

@main
struct ReppyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
